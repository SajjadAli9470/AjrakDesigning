part of 'layred_bloc.dart';

class LayredState {
  final List<LayeredWidget> layredList;

  LayredState({required this.layredList});
  
}
