import 'package:flutter/material.dart';

import 'model/layred_widgets.dart';

Color ajrakColor = Color.fromARGB(255, 85, 1, 1);
Color greyColor = const Color.fromARGB(255, 219, 219, 219);
int index = 0;
double ratio=1;
List<LayeredWidget> layered_widgets = [];
int selectedItem = -1;
Color selectedColor = Colors.white;
double aspect_ratio = 1;
